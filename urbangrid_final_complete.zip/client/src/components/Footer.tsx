import { Link } from "wouter";

export default function Footer() {
  const quickLinks = [
    { name: 'Home', href: '/' },
    { name: 'About Us', href: '/about' },
    { name: 'Our Services', href: '/services' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/contact' },
  ];

  const services = [
    { name: 'New Build Snagging', href: '/services/property-snagging/new-build-snagging' },
    { name: 'Post Renovation Inspection', href: '/services/property-snagging/post-renovation-inspection' },
    { name: 'DLP Snagging', href: '/services/property-snagging/dlp-snagging' },
    { name: 'Move-in/Move-out', href: '/services/property-snagging/move-in-move-out' },
    { name: 'Secondary Market', href: '/services/property-snagging/secondary-market' },
    { name: 'Developer Projects', href: '/services/property-snagging/developer-projects' },
  ];

  return (
    <footer className="bg-brand-black text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="text-2xl font-bold text-white mb-4">UrbanGrid</div>
            <p className="text-gray-300 mb-4">
              Professional property inspection and snagging services across the UAE. Your trusted partner for quality assurance and peace of mind.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-gray-300 hover:text-white transition-colors"
                aria-label="Facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-white transition-colors"
                aria-label="Instagram"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-white transition-colors"
                aria-label="LinkedIn"
              >
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                    Property Inspection UAE
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                    About Snagging Company
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/locations/dubai/snagging-company">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                    Snagging Company Dubai
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                    Property Inspection Blog
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                    Contact Snagging Experts
                  </span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Our Services</h3>
            <ul className="space-y-2 text-sm">
              {services.map((service) => (
                <li key={service.name}>
                  <Link href={service.href}>
                    <span className="text-gray-300 hover:text-white transition-colors cursor-pointer">
                      {service.name}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-4 pt-4 border-t border-gray-700">
              <Link href="/blog">
                <span className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm font-medium">
                  Property Snagging Tips →
                </span>
              </Link>
              <br />
              <Link href="/locations/dubai/property-inspection">
                <span className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  Property Inspection Dubai
                </span>
              </Link>
              <br />
              <Link href="/locations/sharjah/property-inspection">
                <span className="text-gray-300 hover:text-white transition-colors cursor-pointer text-sm">
                  Property Inspection Sharjah
                </span>
              </Link>
            </div>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-start">
                <i className="fas fa-map-marker-alt text-brand-green mr-2 mt-1"></i>
                <span className="text-gray-300">
                  Office 1205, Business Bay<br />Dubai, UAE
                </span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-phone text-brand-green mr-2"></i>
                <a 
                  href="tel:+971585686852" 
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  +971 58 568 6852
                </a>
              </div>
              <div className="flex items-center">
                <i className="fas fa-envelope text-brand-green mr-2"></i>
                <a 
                  href="mailto:info@snagging.me" 
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  info@snagging.me
                </a>
              </div>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300 text-sm">
            © 2024 UrbanGrid Property Inspection Services. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
